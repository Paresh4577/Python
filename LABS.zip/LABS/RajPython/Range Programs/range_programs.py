for i in range(1,11,1):
    print(i)

print("--------------------")

for i in range(10,0,-1):
    print(i)

print("--------------------")

for i in range(-1,-11,-1):
    print(i)

print("--------------------")

for i in range(-10,0,1):
    print(i) # this will not print anything because the range starts from -10 and ends at