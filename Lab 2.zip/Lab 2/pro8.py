unit = int(input("Enter unit:"))
rs = 0
if(unit<=50):
    rs=unit*2.60
elif(unit<=100):
    rs=50*2.60+(unit-50)*3.25
elif(unit<=200):
    rs = 50*2.60+50*3.25+(unit-100)*5.26
else:
    rs = 50*2.60+50*3.25+100*5.26+(unit-200)*8.45



print("The Bill is:",rs)