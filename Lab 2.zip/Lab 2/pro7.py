num1 = int(input("Enter a Number 1:"))
num2 = int(input("Enter a Number 2:"))
choice = input("Enter choice:")
if(choice=='+'):
    print(num1+num2)
elif(choice=='-'):
   print(num1-num2)
elif(choice=='*'):
    print(num1*num2)
elif(choice=='/'):
    print(int(num1/num2))
else:
    print("Invalid Choice!")