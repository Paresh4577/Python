num = int(input("Enter a Number:"))
if num < 0:
    print("The Number is Nagative:")
elif num > 0:
    print("The Number is Positive:")
else:
    print("The Number is Zero:")