num1 = int(input("Enter a Year:"))
if (num1%4==0 and num1%100!=0) or num1%400==0:
    print("The Given Year is Leap Year")
else:
     print("The Given Year is Not Leap Year")