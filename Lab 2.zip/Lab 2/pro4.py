num1 = int(input("Enter a Number 1:"))
num2 = int(input("Enter a Number 2:"))
num3 = int(input("Enter a Number 2:"))
print(num1 if num1>num2 and num1>num3 else num2 if num2>num3 else num3 )