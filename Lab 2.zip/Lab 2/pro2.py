num = int(input("Enter a Number:"))
if num %2== 0:
    print("The Number is Even:")
else:
    print("The Number is odd:")