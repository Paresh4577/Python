num1 = int(input("Enter a Number 1:"))
num2 = int(input("Enter a Number 2:"))
if num1>num2:
    print("The Num1 is Greater:")
else:
    print("The Num2 is Greater:")
# print(num1 if num1>num2 else num2)